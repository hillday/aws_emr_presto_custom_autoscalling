require 'spec_helper'

describe Presto::Metrics do
  it 'has a version number' do
    expect(Presto::Metrics::VERSION).not_to be nil
  end

  it 'does something useful' do
    expect(false).to eq(true)
  end
end
