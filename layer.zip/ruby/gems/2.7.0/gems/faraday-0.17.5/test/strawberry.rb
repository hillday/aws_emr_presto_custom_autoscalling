class MiddlewareStackTest::Strawberry < MiddlewareStackTest::Handler
end
